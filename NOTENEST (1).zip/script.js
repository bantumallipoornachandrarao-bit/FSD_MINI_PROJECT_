(() => {
'use strict';
const KEY = 'notenest.v1', MAX_V = 10, SNAP_MS = 5 * 60 * 1000;
const $ = s => document.querySelector(s);
const uid = () => Math.random().toString(36).slice(2, 10);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = t => new Date(t).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });

/* ---------- sample data (12 notes) ---------- */
const SEED = [
['Dynamic Programming Notes', ['algorithms', 'cs'], "# Dynamic Programming\n\nBreak a problem into **overlapping subproblems** and store results.\n\n## Steps\n1. Define the state\n2. Write the recurrence\n3. Pick base cases\n\n```js\nconst fib = n => n < 2 ? n : fib(n-1) + fib(n-2);\n```\n\n| Problem | Time |\n|---|---|\n| Fibonacci | O(n) |\n| Knapsack | O(nW) |"],
['System Architecture Cheatsheet', ['architecture', 'backend'], "# Distributed Systems\n\n- **Microservices** vs Monolith\n- Cache-aside vs write-through\n- CAP theorem: pick two\n\n`GET /api/v1/health`\n\n> Start simple, split when it hurts."],
['Meeting Minutes - Hackathon Kickoff', ['meeting', 'todo'], "# Hackathon Kickoff\n\n**Attendees:** Asha, Ravi, Meera\n\n## Decisions\n- Build a notes app in vanilla JS\n- Demo on Sunday 4 pm\n\n## Actions\n- [ ] Design the UI\n- [x] Pick the team name\n- [ ] Write the README"],
['Recipe Ideas', ['food', 'personal'], "# Recipe Ideas\n\n- Paneer butter masala\n- Lemon rice with peanuts\n- *Mango lassi* for the weekend\n\n## Shopping\n1. Paneer\n2. Cashews\n3. Fresh curry leaves"],
['Linear Algebra Revision', ['math', 'exam'], "# Linear Algebra\n\n- **Eigenvector:** direction that only scales\n- Rank = number of independent columns\n- det(A) = 0 means not invertible\n\n| Term | Meaning |\n|---|---|\n| Basis | Independent spanning set |\n| Null space | Solutions of Ax = 0 |"],
['Binary Trees Reference', ['algorithms', 'cs'], "# Binary Trees\n\n## Traversals\n- **Inorder:** left, root, right\n- **Preorder:** root, left, right\n- **Postorder:** left, right, root\n\n```js\nfunction inorder(n){ if(!n) return; inorder(n.left); visit(n); inorder(n.right); }\n```"],
['Literature Review: Attention Models', ['research', 'ml'], "# Attention Models\n\nThe core idea: weigh inputs by **relevance** to the query.\n\n> Attention lets a model focus on what matters.\n\n## Papers to read\n- Bahdanau et al. (2014)\n- Vaswani et al. (2017)"],
['Git Commands Cheatsheet', ['tools', 'backend'], "# Git Cheatsheet\n\n- `git status` see changes\n- `git switch -c feature` new branch\n- `git stash` park work\n\n```bash\ngit commit -m \"Add search\"\ngit push origin main\n```"],
['Study Plan - Week 12', ['todo', 'exam'], "# Week 12 Plan\n\n- [x] Finish OS notes\n- [ ] Solve 10 DP problems\n- [ ] Revise DBMS normalization\n\n## Schedule\n| Day | Focus |\n|---|---|\n| Mon | Algorithms |\n| Tue | DBMS |"],
['SQL Joins Explained', ['database', 'cs'], "# SQL Joins\n\n- **INNER JOIN:** rows matching in both\n- **LEFT JOIN:** all left rows, matches on the right\n\n```sql\nSELECT u.name, o.total\nFROM users u LEFT JOIN orders o ON o.user_id = u.id;\n```"],
['Reading List', ['personal', 'research'], "# Reading List\n\n1. *Designing Data-Intensive Applications*\n2. *The Pragmatic Programmer*\n3. *Atomic Habits*\n\n---\n\nRead 20 pages a day."],
['Project Ideas', ['personal', 'todo'], "# Project Ideas\n\n- Habit tracker with streaks\n- Expense splitter\n- **Flashcards** with spaced repetition\n\nPick one with a clear demo path."]
];
function seed() {
  const now = Date.now(), D = 864e5;
  return SEED.map((n, i) => {
    const t = now - i * D * 0.7 - 36e5, b = n[2];
    return { id: uid(), title: n[0], tags: n[1], body: b, pinned: i < 2, trashed: false, updated: t,
      versions: [{ t: t - 3 * D, title: n[0], body: b.slice(0, Math.floor(b.length * .5)) },
                 { t: t - D, title: n[0], body: b.slice(0, Math.floor(b.length * .8)) }] };
  });
}

/* ---------- storage ---------- */
let S = load(), cur = null, view = 'notes', query = '', tagF = null, saveT = null, searchT = null, lastSnap = Date.now(), selV = null;
function load() { try { const d = JSON.parse(localStorage.getItem(KEY)); if (d && Array.isArray(d.notes)) return d; } catch (e) {} return { notes: seed() }; }
function persist() {
  try { localStorage.setItem(KEY, JSON.stringify(S)); return true; }
  catch (e) { S.notes.forEach(n => n.versions = n.versions.slice(-4)); try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e2) {} return false; }
}

/* ---------- markdown (escape first, then regex: XSS-safe) ---------- */
function inline(t) {
  return t.replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/!\[([^\]]*)\]\((https?:[^\s)]+)\)/g, '<img alt="$1" src="$2">')
    .replace(/\[([^\]]+)\]\((https?:[^\s)]+|#[^\s)]*)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*])\*([^*\s][^*]*)\*/g, '$1<em>$2</em>')
    .replace(/~~([^~]+)~~/g, '<del>$1</del>');
}
function md(src) {
  const blocks = [];
  const s = esc(src.replace(/\r/g, '')).replace(/```\w*\n([\s\S]*?)```/g, (_, c) => { blocks.push('<pre><code>' + c + '</code></pre>'); return '\u0000' + (blocks.length - 1) + '\u0000'; });
  const L = s.split('\n'), cells = r => r.trim().replace(/^\||\|$/g, '').split('|').map(c => c.trim());
  let out = '', list = null, para = [];
  const flush = () => { if (para.length) { out += '<p>' + inline(para.join(' ')) + '</p>'; para = []; } };
  const close = () => { if (list) { out += '</' + list + '>'; list = null; } };
  for (let i = 0; i < L.length; i++) {
    const l = L[i]; let m;
    if (/^\u0000\d+\u0000$/.test(l.trim())) { flush(); close(); out += blocks[+l.replace(/\u0000/g, '')]; }
    else if ((m = l.match(/^(#{1,6})\s+(.*)/))) { flush(); close(); out += `<h${m[1].length}>${inline(m[2])}</h${m[1].length}>`; }
    else if (/^\s*([-*_])\1{2,}\s*$/.test(l)) { flush(); close(); out += '<hr>'; }
    else if (/^\|.*\|\s*$/.test(l) && /^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(L[i + 1] || '')) {
      flush(); close();
      const head = cells(l); let rows = ''; i += 2;
      while (i < L.length && /^\|.*\|\s*$/.test(L[i])) { rows += '<tr>' + cells(L[i]).map(c => `<td>${inline(c)}</td>`).join('') + '</tr>'; i++; }
      i--;
      out += `<div class="tw"><table><thead><tr>${head.map(c => `<th>${inline(c)}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table></div>`;
    }
    else if ((m = l.match(/^\s*[-*+]\s+(.*)/))) { flush(); if (list !== 'ul') { close(); out += '<ul>'; list = 'ul'; } out += '<li>' + inline(m[1].replace(/^\[ \]\s/, '\u2610 ').replace(/^\[x\]\s/i, '\u2611 ')) + '</li>'; }
    else if ((m = l.match(/^\s*\d+\.\s+(.*)/))) { flush(); if (list !== 'ol') { close(); out += '<ol>'; list = 'ol'; } out += '<li>' + inline(m[1]) + '</li>'; }
    else if ((m = l.match(/^&gt;\s?(.*)/))) { flush(); close(); out += '<blockquote>' + inline(m[1]) + '</blockquote>'; }
    else if (!l.trim()) { flush(); close(); }
    else { close(); para.push(l.trim()); }
  }
  flush(); close();
  return out;
}

/* ---------- search helpers ---------- */
const words = () => query.toLowerCase().split(/\s+/).filter(Boolean);
const hl = (t, w) => {
  t = esc(t); if (!w.length) return t;
  return t.replace(new RegExp('(' + w.map(x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')', 'gi'), '<mark>$1</mark>');
};
const tagStyle = t => { let h = 0; for (const c of t) h = (h * 31 + c.charCodeAt(0)) % 360; return `background:hsl(${h} 75% 90%);color:hsl(${h} 60% 26%)`; };
function snip(n, w) {
  const p = n.body.replace(/[#*`>|\[\]-]/g, ' ').replace(/\s+/g, ' ').trim();
  let i = 0; if (w.length) { const k = p.toLowerCase().indexOf(w[0]); if (k > 30) i = k - 30; }
  return p.slice(i, i + 90);
}

/* ---------- rendering ---------- */
function renderList() {
  const w = words();
  let notes = S.notes.filter(n => view === 'trash' ? n.trashed : !n.trashed);
  if (tagF) notes = notes.filter(n => n.tags.includes(tagF));
  if (w.length) notes = notes.filter(n => { const h = (n.title + ' ' + n.body + ' ' + n.tags.join(' ')).toLowerCase(); return w.every(x => h.includes(x)); });
  notes.sort((a, b) => b.updated - a.updated);
  const item = n => `<button class="item${cur && n.id === cur.id ? ' on' : ''}" data-id="${n.id}"><b>${hl(n.title || 'Untitled note', w)}</b><span>${hl(snip(n, w), w)}</span><small>${new Date(n.updated).toLocaleDateString([], { month: 'short', day: 'numeric' })}${n.tags.map(t => ` <i style="${tagStyle(t)}">#${hl(t, w)}</i>`).join('')}</small></button>`;
  const pins = view === 'notes' ? notes.filter(n => n.pinned) : [], rest = notes.filter(n => !pins.includes(n));
  $('#noteList').innerHTML = (pins.length ? '<h2>Pinned</h2>' + pins.map(item).join('') : '') +
    (rest.length ? (view === 'notes' ? '<h2>Recently modified</h2>' : '') + rest.map(item).join('') : '') +
    (!notes.length ? `<p class="empty">${view === 'trash' ? 'Trash is empty.' : 'No notes match. Try another word or tag.'}</p>` : '');
  const tags = [...new Set(S.notes.filter(n => !n.trashed).flatMap(n => n.tags))].sort();
  $('#tagFilter').innerHTML = tags.map(t => `<button class="${t === tagF ? 'sel' : ''}" data-tag="${esc(t)}" style="${tagStyle(t)}" aria-pressed="${t === tagF}">#${esc(t)}</button>`).join('');
}
function renderTags() {
  $('#tagChips').innerHTML = cur ? cur.tags.map(t => `<li class="chip" style="${tagStyle(t)}">#${esc(t)}<button data-rm="${esc(t)}" aria-label="Remove tag ${esc(t)}">×</button></li>`).join('') : '';
}
function renderPreview() {
  const b = cur ? cur.body : '';
  $('#preview').innerHTML = md(b);
  const words = (b.trim().match(/\S+/g) || []).length;
  $('#stats').textContent = `${words} words · ${b.length} characters · ${Math.max(1, Math.ceil(words / 200))} min read`;
}
function renderBar() {
  const off = !cur, tr = cur && cur.trashed;
  $('#title').disabled = $('#editor').disabled = off || tr;
  $('#tagInput').disabled = $('#snapBtn').disabled = $('#histBtn').disabled = $('#pinBtn').disabled = off || tr;
  $('#pinBtn').setAttribute('aria-pressed', !!(cur && cur.pinned));
  $('#pinBtn').textContent = cur && cur.pinned ? 'Unpin' : 'Pin';
  $('#trashBtn').textContent = tr ? 'Restore note' : 'Move to trash';
  $('#trashBtn').disabled = off;
  $('#purgeBtn').hidden = !tr;
}
function select(id) {
  cur = S.notes.find(n => n.id === id) || null;
  $('#title').value = cur ? cur.title : '';
  $('#editor').value = cur ? cur.body : '';
  renderList(); renderTags(); renderPreview(); renderBar();
  if (innerWidth <= 820) $('#app').classList.add('collapsed');
}

/* ---------- saving & snapshots ---------- */
function status(t, busy) { const s = $('#saved'); s.textContent = t; s.classList.toggle('busy', !!busy); }
function snapshot() {
  const last = cur.versions[cur.versions.length - 1];
  if (!last || last.body !== cur.body || last.title !== cur.title) {
    cur.versions.push({ t: Date.now(), title: cur.title, body: cur.body });
    while (cur.versions.length > MAX_V) cur.versions.shift();
  }
  lastSnap = Date.now();
}
function save(snap) {
  if (!cur) return;
  clearTimeout(saveT);
  if (snap || Date.now() - lastSnap > SNAP_MS) snapshot();
  status(persist() ? (snap ? 'Snapshot saved' : 'Saved locally') : 'Storage full: older versions pruned');
  renderList();
}
function touch() { cur.updated = Date.now(); status('Saving…', true); clearTimeout(saveT); saveT = setTimeout(() => save(false), 2000); }

/* ---------- actions ---------- */
function newNote() {
  const n = { id: uid(), title: 'Untitled note', body: '# Untitled note\n\n', tags: [], pinned: false, trashed: false, updated: Date.now(), versions: [] };
  S.notes.push(n); view = 'notes'; setView(); persist(); select(n.id);
  $('#title').focus(); $('#title').select();
}
function setView() {
  $('#vNotes').classList.toggle('on', view === 'notes'); $('#vTrash').classList.toggle('on', view === 'trash');
  $('#vNotes').setAttribute('aria-pressed', view === 'notes'); $('#vTrash').setAttribute('aria-pressed', view === 'trash');
  renderList();
}
function addTag(raw) {
  const t = raw.toLowerCase().replace(/^#+/, '').replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '');
  if (!cur || !t || cur.tags.includes(t)) return;
  cur.tags.push(t); touch(); save(false); renderTags();
}
function openHist() { if (!cur) return; selV = cur.versions.length - 1; renderHist(); $('#drawer').classList.add('open'); $('#closeHist').focus(); }
function renderHist() {
  const vs = cur.versions;
  $('#vList').innerHTML = vs.length ? vs.map((v, i) => `<li><button data-i="${i}" class="${i === selV ? 'on' : ''}">${fmt(v.t)}<small>${v.body.length} characters</small></button></li>`).reverse().join('') : '<li class="empty" style="color:var(--mute)">No snapshots yet. Use Save snapshot.</li>';
  const v = vs[selV];
  $('#vPrev').innerHTML = v ? `<h2>${esc(v.title)}</h2>` + md(v.body) : '<p>Pick a version to preview it here.</p>';
  $('#restore').disabled = !v;
}
function restore() {
  const v = cur.versions[selV]; if (!v) return;
  snapshot();
  cur.title = v.title; cur.body = v.body; cur.updated = Date.now();
  persist(); $('#drawer').classList.remove('open'); select(cur.id);
  status('Restored version from ' + fmt(v.t));
}
function dl(name, type, data) {
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([data], { type })); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
function exportNote(kind) {
  if (!cur) return;
  const name = (cur.title || 'note').replace(/[^\w-]+/g, '-').toLowerCase();
  const html = `<!doctype html><meta charset="utf-8"><title>${esc(cur.title)}</title><style>body{font:16px/1.6 Georgia,serif;max-width:720px;margin:2rem auto;padding:0 1rem}pre{background:#f3f4f6;padding:1rem;overflow:auto}table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:.3rem .6rem}</style><h1>${esc(cur.title)}</h1>${md(cur.body)}`;
  if (kind === 'md') dl(name + '.md', 'text/markdown', cur.body);
  else if (kind === 'html') dl(name + '.html', 'text/html', html);
  else { const f = document.createElement('iframe'); f.style.cssText = 'position:fixed;width:0;height:0;border:0'; document.body.append(f); f.onload = () => { f.contentWindow.print(); setTimeout(() => f.remove(), 3000); }; f.srcdoc = html; }
}

/* ---------- events ---------- */
$('#editor').addEventListener('input', e => { cur.body = e.target.value; touch(); renderPreview(); });
$('#title').addEventListener('input', e => { cur.title = e.target.value; touch(); });
$('#editor').addEventListener('scroll', e => {
  const t = e.target, p = $('#preview'), r = t.scrollTop / Math.max(1, t.scrollHeight - t.clientHeight);
  p.scrollTop = r * (p.scrollHeight - p.clientHeight);
});
$('#search').addEventListener('input', e => { clearTimeout(searchT); searchT = setTimeout(() => { query = e.target.value; renderList(); }, 180); });
$('#noteList').addEventListener('click', e => { const b = e.target.closest('[data-id]'); if (b) select(b.dataset.id); });
$('#tagFilter').addEventListener('click', e => { const b = e.target.closest('[data-tag]'); if (b) { tagF = tagF === b.dataset.tag ? null : b.dataset.tag; renderList(); } });
$('#tagChips').addEventListener('click', e => { const b = e.target.closest('[data-rm]'); if (b) { cur.tags = cur.tags.filter(t => t !== b.dataset.rm); touch(); save(false); renderTags(); } });
$('#tagInput').addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); addTag(e.target.value); e.target.value = ''; } });
$('#newBtn').onclick = newNote;
$('#vNotes').onclick = () => { view = 'notes'; setView(); };
$('#vTrash').onclick = () => { view = 'trash'; setView(); };
$('#menuBtn').onclick = () => { const c = $('#app').classList.toggle('collapsed'); $('#menuBtn').setAttribute('aria-expanded', !c); };
$('#pinBtn').onclick = () => { cur.pinned = !cur.pinned; persist(); renderBar(); renderList(); };
$('#snapBtn').onclick = () => save(true);
$('#histBtn').onclick = openHist;
$('#closeHist').onclick = () => $('#drawer').classList.remove('open');
$('#vList').addEventListener('click', e => { const b = e.target.closest('[data-i]'); if (b) { selV = +b.dataset.i; renderHist(); } });
$('#restore').onclick = restore;
$('#trashBtn').onclick = () => { cur.trashed = !cur.trashed; cur.updated = Date.now(); persist(); renderBar(); renderList(); status(cur.trashed ? 'Moved to trash' : 'Note restored'); };
$('#purgeBtn').onclick = () => {
  if (!confirm('Delete this note forever? This cannot be undone.')) return;
  S.notes = S.notes.filter(n => n !== cur); persist();
  const next = S.notes.find(n => n.trashed === (view === 'trash')); select(next ? next.id : null);
};
$('#exp').addEventListener('click', e => { const b = e.target.closest('[data-x]'); if (b) { exportNote(b.dataset.x); $('#exp').open = false; } });
$('#tWrite').onclick = () => tab('write'); $('#tView').onclick = () => tab('preview');
function tab(v) { $('#panes').dataset.view = v; $('#tWrite').classList.toggle('on', v === 'write'); $('#tView').classList.toggle('on', v === 'preview'); }
document.addEventListener('keydown', e => {
  const k = e.key.toLowerCase();
  if ((e.ctrlKey || e.metaKey) && k === 's') { e.preventDefault(); save(true); }
  else if ((e.ctrlKey || e.metaKey) && k === 'k') { e.preventDefault(); $('#app').classList.remove('collapsed'); $('#search').focus(); }
  else if (e.altKey && k === 'n') { e.preventDefault(); newNote(); }
  else if (k === 'escape') $('#drawer').classList.remove('open');
});
setInterval(() => { if (cur && !cur.trashed && Date.now() - lastSnap > SNAP_MS) save(false); }, 30000);
addEventListener('beforeunload', () => { if (cur) persist(); });

/* ---------- start ---------- */
if (innerWidth <= 820) $('#app').classList.add('collapsed');
persist();
const first = S.notes.find(n => !n.trashed);
select(first ? first.id : null);
})();
